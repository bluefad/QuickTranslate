-- AlterTable
ALTER TABLE "Module" ALTER COLUMN "description" DROP NOT NULL;

-- AlterTable
ALTER TABLE "Project" ALTER COLUMN "description" DROP NOT NULL;
